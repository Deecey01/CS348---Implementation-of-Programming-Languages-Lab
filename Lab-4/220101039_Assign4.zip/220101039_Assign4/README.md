Name     : Divyansh Chandak
Roll No. : 220101039
Assignment - 4

Question 1
A Two-Pass Assembler is created which generates machine code from assembly code in two passes.

How to run?
g++ 220101039_Task1.cpp -o 220101039_Task1
./220101039_Task1

Following this, 2 files would be generated, namely the intermediate.txt(which contains the intermediate code) and the output.txt(which contains the final machine level code).


Question 2 (Just a try)
A One-Pass Assembler is created which generates machine code from assembly code in one pass without generating an intermediate code.

How to run?
g++ 220101039_Task2.cpp -o 220101039_Task2
./220101039_Task2

The final machine code is generated in output.txt without any intermediate.txt.



NOTE: For the code to work properly and generate the desired output, the input file must have a tab(\t) after each line in the sample_input.txt file.